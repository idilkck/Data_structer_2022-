public class Node {
    int data;
    Node next=null;

    public Node(int data){
        this.next = null;
        this.data=data;
	}
}